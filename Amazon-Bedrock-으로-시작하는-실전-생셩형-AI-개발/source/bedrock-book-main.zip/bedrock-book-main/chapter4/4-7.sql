ALTER TABLE bedrock_integration.bedrock_kb
  ADD COLUMN product VARCHAR(128),
  ADD COLUMN area VARCHAR(128)
